const express = require('express');
const routes = express.Router();
const controle = require('../controller/ColaboradorCont');

//Aqui vão todos os endpoints possíveis para o programa
routes.route('/colaboradores').get(controle.listar);
routes.route('/colaboradores').post(controle.incluir);

module.exports = routes;

